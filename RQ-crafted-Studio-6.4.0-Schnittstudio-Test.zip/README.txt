RQ-crafted Studio 6.4.0 – Schnittstudio Test

Basis: funktionierende 6.3.2 mit Projektrettung.
Änderungen: kompaktere mobile Studio-Ansicht, feste Projektleiste, 16:9-Vorschau, horizontale Timeline, Ausblenden leerer Spuren.
Projekt- und Backup-Importcode unverändert.

WICHTIG: Vor dem Upload eine Projektsicherung erstellen und die alte index.html separat aufbewahren.
Die Darstellung auf iPhone Safari ist noch nicht praktisch getestet.
